#!/usr/bin/env python3

def main():
    print('Welcome to the Brain Games!')

def greet(who):
    print(f'Hello, {who}!')

if __name__ == '__main__':
    main()
