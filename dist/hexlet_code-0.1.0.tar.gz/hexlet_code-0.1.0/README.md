### Hexlet tests and linter status:
[![Actions Status](https://github.com/Alex-Stas/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Alex-Stas/python-project-49/actions)
### Codeclimate status:
[![Maintainability](https://api.codeclimate.com/v1/badges/ce1ff8ee990a77a19b2d/maintainability)](https://codeclimate.com/github/Alex-Stas/python-project-49/maintainability)
