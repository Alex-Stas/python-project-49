from brain_games import main

main()
